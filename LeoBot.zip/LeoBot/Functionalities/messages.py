import Leo
import random

class Messages:
    #   The methods return a random message out of these options below.
    #   Parameter os set to name which is invokes while typing in the command.
    def randomBirtdayMessage(name):
        #   by default the start value for an array is [0].
        messages = ['Happy Birthday, ' + name + '!',
                    name + ', Many many returns of the day! Happy birthday!',
                    'May you live long, happy birthday' + name + '!',
                    'ADD',
                    'ADD']
        #   StartPoint, EndPoint, Increment
        randomNum = random.randrange(0, messages.__len__() - 1, 1) #    messages.__len__ return length of array
        return messages[randomNum]

    #   Overloading methods to make it work without parameter, MAYBE UNNECESSARY
    def randomBirthdayMessage(self):
        messages = ['Happy Birthday!',
                    'Many many returns of the day! Happy birthday!',
                    'May you live long, happy birthday',
                    'ADD',
                    'ADD']
        #   StartPoint, EndPoint, Increment
        randomNum = random.randrange(0, messages.__len__() - 1, 1) #    messages.__len__ return length of array
        return messages[randomNum]


    def randomGreetingMessageAndPicture(name):
        #   To be figured out
        return '' # Returns nothing

