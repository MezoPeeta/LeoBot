# LeoBot
A basic python bot!
Credits: https://github.com/MezoPeeta.
Integrating with intuitive ideas and functionalities which could be of utmost use for other bots too.
Stay tuned.....
