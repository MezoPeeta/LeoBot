import Leo

class moderators:

    # Returns some information about the user
    def checkInfo(name):
        info = ''
        return info

    #   Kicks a user with a message
    def kickUser(name):
        return

    #   delete n number of messages
    def deleteMessage(number):
        for x in range(number - 1):
            #   Delete function
            print('Message deleted!')
        return number + ' messages deleted'

    #   delete messages except pinned
    def delMessagesNoPin(number):
        for x in range(number - 1):
            #   Delete function
            print('Messages deleted!')
        return number + ' messages deleted'